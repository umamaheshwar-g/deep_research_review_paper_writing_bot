import os

def find_files_with_null_bytes(directory='.'):
    """Find Python files containing null bytes."""
    files_with_null_bytes = []
    
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'rb') as f:
                        content = f.read()
                        if b'\x00' in content:
                            files_with_null_bytes.append(file_path)
                            print(f"Found null bytes in: {file_path}")
                except Exception as e:
                    print(f"Error reading {file_path}: {e}")
    
    return files_with_null_bytes

if __name__ == "__main__":
    print("Searching for Python files with null bytes...")
    files = find_files_with_null_bytes()
    
    if not files:
        print("No files with null bytes found.")
    else:
        print("\nFiles with null bytes:")
        for file in files:
            print(f"- {file}") 