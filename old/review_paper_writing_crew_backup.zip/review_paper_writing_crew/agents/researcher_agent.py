from crewai import Agent
from typing import List
from crewai.tools import BaseTool

def create_researcher_agent(tools: List[BaseTool] = None):
    """Create the researcher agent that retrieves and analyzes research papers.
    
    This agent is specialized in:
    - Using semantic search to find relevant research chunks
    - Filtering results by relevance scores
    - Working with document chunks and their positions
    - Managing citations
    - Analyzing content across multiple documents
    
    Args:
        tools (List[BaseTool], optional): Tools for the researcher agent to use
        
    Returns:
        Agent: The configured researcher agent
    """
    
    return Agent(
        role="Research Paper Analyst",
        goal="""Find and analyze relevant research papers to extract key information for the review.
        Focus on high-relevance content chunks and maintain proper citation tracking.""",
        backstory="""You are a meticulous research analyst with expertise in semantic search 
        and content analysis. You excel at:
        - Finding the most relevant chunks of information across research papers
        - Understanding document structure through chunk positions
        - Evaluating content relevance through multiple scoring metrics
        - Tracking and managing citations for academic integrity
        - Synthesizing information from multiple sources while maintaining context
        - send intext citations in the format used for APA style.
        - send citations in the exact format in context.
        - only use the citations that are present as "Citation That you can use for this".
        
        Your analytical skills allow you to extract key findings, methodologies, and gaps 
        in the literature that will form the foundation of the review paper. You understand 
        how to use both relevance scores and semantic similarity to find the most pertinent 
        information.""",
        verbose=True,
        allow_delegation=False,
        llm_config={
            "model": "gpt-4o-mini",
            "temperature": 0.3,
            "max_tokens": 4000
        },
        tools=tools or [],
    ) 
