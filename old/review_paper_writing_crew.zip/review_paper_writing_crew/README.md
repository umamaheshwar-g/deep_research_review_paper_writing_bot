# Research Review Paper Writing Crew

This project uses CrewAI to generate comprehensive research review papers based on research papers stored in a Pinecone vector database.

## Overview

The system uses a hierarchical team of AI agents to:

1. Research a topic using papers stored in Pinecone
2. Write a comprehensive review paper
3. Edit and refine the paper to publication quality

## Architecture

The system consists of four specialized agents:

- **Manager Agent**: Coordinates the overall process and delegates tasks
- **Researcher Agent**: Searches and analyzes research papers in Pinecone
- **Writer Agent**: Creates a structured review paper based on research findings
- **Editor Agent**: Refines and polishes the paper to ensure quality

## Prerequisites

- Python 3.9+
- OpenAI API key
- Pinecone API key
- Pinecone index with research papers (vector embeddings)

## Installation

1. Clone this repository
2. Install dependencies:

```powershell
pip install -r requirements.txt
```

3. Create a `.env` file with your API keys:

```
OPENAI_API_KEY=your_openai_api_key
PINECONE_API_KEY=your_pinecone_api_key
```

## Usage

Run the main script with your desired topic:

```powershell
python main.py --topic "Your Research Topic" --output output_filename.md
```

### Command Line Arguments

- `--topic`: The research topic to review (default: "Diffusion Large Language Models")
- `--output`: Output filename for the review paper (default: "review_paper.md")
- `--namespace`: Pinecone namespace to use (default: generates a new UUID)

## How It Works

The system uses a hierarchical process where:

1. The Manager Agent creates a plan and delegates tasks to the appropriate agents
2. The Researcher Agent uses the PineconeRetriever tool to find relevant research
3. The Writer Agent creates a structured draft based on the research
4. The Editor Agent refines the paper to ensure quality and academic standards

### Hierarchical Process

This project uses CrewAI's hierarchical process, which simulates a corporate hierarchy where:

- A manager agent oversees the entire workflow
- Tasks are not pre-assigned to specific agents
- The manager delegates tasks to the most appropriate agents based on their roles and capabilities
- The manager validates the results of each task before proceeding to the next
- The workflow follows a logical sequence while allowing for flexible task delegation

This approach is more efficient than a sequential process for complex tasks like writing a research review paper, as it allows for better coordination and quality control.

## Pinecone Schema

The system expects research papers to be chunked and stored in Pinecone with the following metadata:

- `local_id`: Unique identifier for the document
- `title`: Paper title
- `authors`: Paper authors
- `year`: Publication year
- `position`: Position of the chunk within the document (0.0 to 1.0)
- `citation`: Citation information

## Customization

You can customize the agents by modifying the files in the `agents/` directory:

- `manager_agent.py`: Configure the manager agent
- `researcher_agent.py`: Configure the researcher agent
- `writer_agent.py`: Configure the writer agent
- `editor_agent.py`: Configure the editor agent

## Troubleshooting

If you encounter issues with the hierarchical process:

1. Check that all agents have appropriate backstories and goals
2. Ensure the task descriptions are clear and specific
3. Verify that the PineconeRetriever tool is properly configured
4. Check that your Pinecone index contains properly formatted research paper chunks
5. Make sure the manager agent has `allow_delegation=True`
6. Do not pre-assign agents to tasks when using hierarchical process

## License

[MIT License](LICENSE) 