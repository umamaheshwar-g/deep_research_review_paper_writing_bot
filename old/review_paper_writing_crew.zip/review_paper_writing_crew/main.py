# Main entry point for the research paper writing crew
# Make langtrace optional
try:
    from langtrace_python_sdk import langtrace
    langtrace.init(api_key = 'b3972c908d04c709e6805d45e5fba780aacd5256e21614f4e543391f5edf8ec3')
    print("Langtrace initialized successfully.")
except ImportError:
    print("Langtrace module not found. Continuing without tracing.")

import os
import argparse
import uuid
from dotenv import load_dotenv
from crewai import Crew, Agent, Task, Process

# Import our custom agents
from agents.manager_agent import create_manager_agent
from agents.researcher_agent import create_researcher_agent
from agents.writer_agent import create_writer_agent
from agents.editor_agent import create_editor_agent

# Import our retriever tool
from tools.retriever import PineconeRetriever

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Generate a research review paper for a given topic in ')
    parser.add_argument('--topic', type=str, default="Diffusion Large Language Models", help='The research topic to review')
    parser.add_argument('--output', type=str, default='review_paper.md', help='Output filename')
    parser.add_argument('--namespace', type=str, default=None, help='Pinecone namespace (UUID will be generated if not provided)')
    return parser.parse_args()

def main():
    """Main entry point for the application."""
    # Load environment variables
    load_dotenv()
    
    # Parse command line arguments
    args = parse_arguments()
    
    # Use the provided namespace or generate a new one
    namespace = args.namespace if args.namespace else str(uuid.uuid4())
    print(f"Using namespace: {namespace}")
    
    # Initialize the retriever tool
    retriever = PineconeRetriever(namespace=namespace)
    
    # Create agents
    manager = create_manager_agent()
    researcher = create_researcher_agent(tools=[retriever])
    writer = create_writer_agent(tools=[retriever])
    editor = create_editor_agent(tools=[retriever])
    
    # Create research, writing, and editing task
    paper_generation_task = Task(
        description=f"""Generate a comprehensive review paper on "{args.topic}" through a systematic research process.

        ## RESEARCH PHASE
        Use the PineconeRetriever tool to conduct a thorough literature review on {args.topic}. Follow this research methodology:

        1. EXPLORATORY RESEARCH:
           - Start with broad queries to understand the landscape of {args.topic}
           - Example: "Overview of {args.topic}" or "Key concepts in {args.topic}"
           - Use top_k: 15-20 to get a wide range of initial results

        2. FOCUSED RESEARCH:
           - Identify key subtopics, methodologies, and trends from initial results
           - Create specific queries for each important aspect
           - Example: "Latest advancements in {args.topic}" or "Evaluation metrics for {args.topic}"
           - Track paper IDs (local_id) of seminal or highly relevant papers

        3. COMPARATIVE ANALYSIS:
           - Use local_ids parameter to compare specific papers on similar topics
           - Example: local_ids: ["paper_123", "paper_456"] with a query about their methodologies
           - Identify agreements, disagreements, and research gaps

        4. SECTION-TARGETED RESEARCH:
           - Use section_range parameter to focus on specific parts of papers
           - For methodology details: section_range: [0.15, 0.45]
           - For results and findings: section_range: [0.45, 0.75]
           - For conclusions and future work: section_range: [0.9, 1.0]

        5. CITATION COLLECTION:
           - Maintain a bibliography of all important papers
           - Record full citations from search results for later reference
           - Ensure diverse sources (different research groups, time periods, approaches)

        ## PAPER STRUCTURE
        Organize your findings into a well-structured review paper with:

        - Title: A clear, descriptive title for the review paper
        - Abstract: Summary of the topic, methodology, key findings, and significance (150-250 words)
        - Introduction: Background, motivation, research questions, and scope of the review
        - Literature Review: Organized by themes, approaches, or chronology
        - Methodology Analysis: Comparison of research methodologies in the field
        - Results and Findings: Synthesis of key results across the literature
        - Discussion: Analysis of trends, contradictions, and research gaps
        - Future Directions: Promising research avenues and open challenges
        - Conclusion: Summary of key insights and contributions
        - References: Properly formatted citations for all sources

        ## QUALITY STANDARDS
        Ensure the paper meets these academic standards:
        - Comprehensive coverage of the topic (3000-6000 words)
        - Clear organization and logical flow
        - Balanced presentation of different perspectives
        - Critical analysis rather than mere description
        - Proper citation of all sources
        - Academic writing style and terminology
        - Publication-ready formatting and structure
        """,
        expected_output="""A 3000-6000 words research paper on the assigned topic "{args.topic}" """
    )
    
    # Create the crew with hierarchical process
    crew = Crew(
        # agents=[researcher, writer, editor],
        agents=[researcher],
        tasks=[paper_generation_task],
        verbose=True,
        manager_agent=manager,
        process=Process.hierarchical,
        planning=True  # Enable planning for hierarchical process
    )
    
    # Run the crew
    result = crew.kickoff()
    
    # Save the result to the output file
    with open(args.output, 'w', encoding='utf-8') as f:
        if hasattr(result, 'final_output'):
            f.write(result.final_output)
        elif hasattr(result, 'raw_output'):
            f.write(result.raw_output)
        else:
            f.write(str(result))
    
    print(f"Review paper has been written and saved to {args.output}")

if __name__ == "__main__":
    main() 