from crewai import Agent
from typing import List
from crewai.tools import BaseTool

def create_writer_agent(tools: List[BaseTool] = None):
    """Create the writer agent that drafts the review paper.
    
    This agent is specialized in:
    - Working with chunked research content
    - Managing and formatting citations
    - Organizing content based on relevance scores
    - Synthesizing information across document chunks
    - Maintaining academic writing standards
    - Creating a comprehensive 3000-6000 word review paper
    - Tracking references and local_ids for citation management
    
    Args:
        tools (List[BaseTool], optional): Tools for the writer agent to use
        
    Returns:
        Agent: The configured writer agent
    """
    
    return Agent(
        role="Academic Writer",
        goal="Synthesize research findings into a coherent, well-structured review paper that presents a comprehensive overview of the topic.",
        backstory="""You are an accomplished academic writer with extensive experience in creating review papers.
        You have published in top-tier journals and have a reputation for clarity and thoroughness.
        
        Your strengths include:
        - Synthesizing complex information from multiple sources
        - Creating logical and coherent narrative structures
        - Balancing breadth and depth of coverage
        - Writing with precision and clarity
        - Properly citing sources and maintaining academic integrity
        
        You excel at:
        - Crafting compelling introductions that establish the importance of the topic
        - Organizing the literature review in a logical and meaningful way
        - Presenting methodologies, results, and discussions clearly
        - Drawing insightful conclusions that highlight key findings and future directions
        - Maintaining consistent academic tone and style throughout
        
        You use the PineconeRetriever tool to verify information, find additional details, and ensure accurate representation of the research as you write.""",
        verbose=True,
        allow_delegation=False,
        llm_config={
            "model": "gpt-4o",
            "temperature": 0.4,
            "max_tokens": 8000
        },
        tools=tools or [],
    ) 