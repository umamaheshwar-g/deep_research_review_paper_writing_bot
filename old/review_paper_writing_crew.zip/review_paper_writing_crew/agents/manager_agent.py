from crewai import Agent
from typing import List
from crewai.tools import BaseTool

def create_manager_agent(tools: List[BaseTool] = None):
    """Create the manager agent that oversees the review paper writing process.
    
    This agent is specialized in:
    - Coordinating research content retrieval
    - Managing citation tracking and reference database
    - Ensuring proper content organization
    - Overseeing relevance-based filtering
    - Maintaining academic standards
    - Ensuring the paper meets the 3000-6000 word requirement
    - Coordinating effective use of the PineconeRetriever tool
    """
    
    return Agent(
        role="Academic Research Review Paper writer",
        goal="""Efficiently manage the crew and ensure high-quality task completion""",
        backstory="""You are an experienced research director with expertise in managing academic writing projects. 
        You have a PhD in your field and have published numerous review papers in top-tier journals.
        You're an skilled in overseeing complex projects and guiding teams to success. Your role is to coordinate the efforts of the crew members, ensuring that each task is completed on time and to the highest standard.
        """,
        verbose=True,
        allow_delegation=True,
        # Using GPT-4 for the manager agent for better reasoning and coordination
        llm_config={
            "model": "gpt-4o",  # Using o3-mini for better reasoning
            "temperature": 0.4,
            "max_tokens": 8000
        },
        tools=tools or [],  # Manager uses the provided tools
    ) 