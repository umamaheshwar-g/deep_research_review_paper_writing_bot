from crewai import Agent
from typing import List
from crewai.tools import BaseTool

def create_researcher_agent(tools: List[BaseTool] = None):
    """Create the researcher agent that retrieves and analyzes research papers.
    
    This agent is specialized in:
    - Using semantic search to find relevant research chunks
    - Filtering results by relevance scores
    - Providing results in a way that is easy to understand and use for writing research paper with local_id, reference, chunk, etc for every finding
    - fetching content across multiple documents
    - Tracking local_ids for deeper research
    
    Args:
        tools (List[BaseTool], optional): Tools for the researcher agent to use
        
    Returns:
        Agent: The configured researcher agent
    """
    
    return Agent(
        role="Research Analyst",
        goal="""To Gather and provide relevant results from the research corpus that answers the research question
        and format the results in a way that is easy to understand and use for writing research paper with local_id, reference, chunk, etc for every finding""",
        backstory=""" You are an expert in searching and retrieving relevant chunks from research papers from the research corpus using semantic search and filtering results smartly""",
        verbose=True,
        allow_delegation=False,
        llm_config={
            "model": "gpt-4o",
            "temperature": 0.3,
            "max_tokens": 8000
        },
        tools=tools or [],
    ) 
