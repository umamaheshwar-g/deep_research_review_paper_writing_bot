import os
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from pinecone import Pinecone
from openai import OpenAI

class PineconeRetrieverInput(BaseModel):
    """Schema for PineconeRetriever tool inputs."""
    query: str = Field(description="""A detailed search query text with specific keywords related to research papers. 
                       Be specific about concepts, methodologies, or findings you're looking for.
                       This query will be used to find similar documents using cosine similarity""")
    local_ids: Optional[List[str]] = Field(
        default=None, 
        description="""Optional list of document IDs to search within specific research papers. 
        Use this when you want to focus on particular papers you've already identified.
        The tool will use efficient filtering to match documents with these IDs.
        Examples:
        - Single paper: ["paper_123"] - Uses $eq filter operator
        - Multiple papers: ["paper_123", "paper_456"] - Uses $in filter operator
        - All papers: leave empty or null"""
    )
    section_range: Optional[List[float]] = Field(
        default=None,
        description="""Optional start and end percentages of a research paper as [start, end] to search within specific sections of paper/papers.
        The tool converts these percentages to chunk IDs and applies range filters.
        For example: 
        - [0.0, 0.15] for introductions (first 15%)
        - [0.15, 0.45] for methodology
        - [0.45, 0.75] for results
        - [0.75, 0.9] for discussion
        - [0.9, 1.0] for conclusions
        This helps you target specific parts of papers when you know where the information is likely to be found."""  
    )
    min_score: float = Field(
        default=0.0, 
        description="""Minimum relevance score threshold (0.0 to 1.0). 
        The tool applies a $gte (greater than or equal) filter on the score field.
        - Higher values (e.g., 0.7+): Only highly relevant results
        - Medium values (e.g., 0.3-0.6): Moderately relevant results
        - Lower values (e.g., 0.0-0.2): Wide variety of potentially relevant results"""
    )
    top_k: int = Field(
        default=10, 
        description="""Number of results to return after filtering and ranking.
        - Lower values (e.g., 3-5): Focused, high-precision results
        - Medium values (e.g., 10-15): Balanced coverage
        - Higher values (e.g., 20+): Comprehensive coverage for literature reviews"""
    )

class PineconeRetriever(BaseTool):
    """Tool for retrieving information from Pinecone vector database using chunk-based schema."""
    
    name: str = "PineconeRetriever"
    description: str = """Retrieves relevant research paper information from a Pinecone vector database.

    USAGE GUIDE FOR AGENTS:
    This tool performs semantic search across research papers to find relevant information. Each paper is chunked into 
    smaller pieces for more precise retrieval. Use this tool to find specific information, compare methodologies, 
    identify trends, or gather evidence for your research paper.

    To use this tool effectively:
    
    1. QUERY FORMULATION:
       - query: Provide a detailed, specific query that clearly describes what you're looking for
       - Example good queries:
         * General topic: "Latest advancements in diffusion models for text-to-image generation"
         * Specific concept: "How do transformer architectures handle long-range dependencies?"
         * Comparative analysis: "Differences between BERT and GPT architectures for NLP tasks"
         * Targeted information: "Evaluation metrics used in recent reinforcement learning papers"
    
    2. FILTERING OPTIONS:
       - local_ids: Filter to specific papers when you know their IDs
         * Single paper: ["paper_123"] 
         * Multiple papers: ["paper_123", "paper_456", "paper_789"]
         * Compare specific approaches: Use with comparative queries to analyze different papers
       
       - section_range: Target specific sections of papers
         * Introduction [0.0, 0.15]: For problem statements, motivation, and background
         * Methodology [0.15, 0.45]: For algorithms, approaches, and experimental design
         * Results [0.45, 0.75]: For findings, performance metrics, and comparisons
         * Discussion [0.75, 0.9]: For analysis, limitations, and implications
         * Conclusion [0.9, 1.0]: For summaries and future work directions
       
       - min_score: Control relevance threshold
         * High precision (0.7+): When you need only the most relevant results
         * Balanced (0.3-0.6): When you want relevant but diverse perspectives
         * Exploratory (0.0-0.2): When casting a wide net for initial research
       
       - top_k: Control number of results
         * Focused (3-5): Quick answers to specific questions
         * Standard (10-15): Typical research queries
         * Comprehensive (20+): In-depth literature reviews
    
    3. SEARCH STRATEGIES:
       - Broad-to-narrow: Start with general queries, then refine based on initial results
       - Paper-specific: When you find an interesting paper, use its ID to explore it in depth
       - Comparative: Use local_ids with multiple papers to compare approaches
       - Section-targeted: Use section_range to focus on specific parts of papers
       - Combined: Mix strategies for complex research questions
    
    4. EXAMPLE SEARCH PATTERNS:
       - Initial exploration: {query: "Overview of diffusion models", top_k: 15}
       - Deep dive: {query: "Training methodology", local_ids: ["paper_123"], section_range: [0.15, 0.45]}
       - Comparison: {query: "Performance evaluation", local_ids: ["paper_123", "paper_456"], min_score: 0.5}
       - Literature review: {query: "Recent advances in attention mechanisms", top_k: 20, min_score: 0.3}
       
    5. RESEARCH PAPER WORKFLOW:
       - Start with broad queries to identify key papers and concepts
       - Track paper IDs (local_id) for important sources to reference later
       - Use section targeting to find specific information (methods, results, etc.)
       - Compare multiple papers on the same topic to identify consensus and disagreements
       - Collect citations for your bibliography as you go
    """
    
    args_schema: type[BaseModel] = PineconeRetrieverInput
    
    def __init__(self, namespace: str, index_name: str = "deepresearchreviewbot", debug: bool = True):
        """Initialize the PineconeRetriever tool."""
        super().__init__()
        self._namespace = namespace
        self._index_name = index_name
        self._debug = debug
        self._debug_file = self._setup_debug_file()
        
        # Initialize Pinecone and OpenAI clients
        pinecone_api_key = os.getenv("PINECONE_API_KEY")
        openai_api_key = os.getenv("OPENAI_API_KEY")
        
        if not pinecone_api_key or not openai_api_key:
            raise ValueError("PINECONE_API_KEY or OPENAI_API_KEY not found in environment variables")
        
        self._pc = Pinecone(api_key=pinecone_api_key)
        self._openai_client = OpenAI(api_key=openai_api_key)
        self._index = self._pc.Index(self._index_name)
        
        self._log_debug("Initialized PineconeRetriever")

    def _setup_debug_file(self) -> Path:
        """Set up debug log file with timestamp."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        debug_dir = Path("debug_logs")
        debug_dir.mkdir(exist_ok=True)
        return debug_dir / f"retriever_debug_{timestamp}.log"

    def _log_debug(self, message: str, data: Any = None) -> None:
        """Log debug information to file if debug is enabled."""
        if not self._debug:
            return
            
        timestamp = datetime.now().isoformat()
        log_entry = {
            "timestamp": timestamp,
            "message": message,
            "data": data
        }
        
        with open(self._debug_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry, default=str) + "\n")

    def _get_chunk_range(self, section_range: List[float], total_chunks: int) -> Tuple[int, int]:
        """Calculate absolute chunk numbers from percentage range."""
        start_pct, end_pct = section_range
        # Ensure percentages are within valid range
        start_pct = max(0.0, min(1.0, start_pct))
        end_pct = max(0.0, min(1.0, end_pct))
        
        # Calculate absolute chunk numbers
        start_chunk = int(start_pct * total_chunks)
        end_chunk = int(end_pct * total_chunks)
        
        return start_chunk, end_chunk

    def run(self, tool_input: Union[str, Dict[str, Any]]) -> str:
        """Execute the tool with the given input."""
        self._log_debug("Tool execution started", {"input": tool_input})
        
        try:
            # Handle string input as just a query
            if isinstance(tool_input, str):
                self._log_debug("Processing string input as query")
                result = self._run(query=tool_input)
            else:
                # Handle dict input with full parameters
                self._log_debug("Processing dictionary input")
                # Handle backward compatibility with local_id parameter
                local_ids = tool_input.get("local_ids")
                if local_ids is None and "local_id" in tool_input:
                    # Convert single local_id to list if the old parameter is used
                    local_id = tool_input.get("local_id")
                    local_ids = [local_id] if local_id else None
                
                result = self._run(
                    query=tool_input.get("query"),
                    local_ids=local_ids,
                    section_range=tool_input.get("section_range"),
                    min_score=tool_input.get("min_score", 0.0),
                    top_k=tool_input.get("top_k", 10)
                )
            
            self._log_debug("Tool execution completed successfully")
            return result
            
        except Exception as e:
            error_msg = f"Error executing tool: {str(e)}"
            self._log_debug("Tool execution failed", {"error": error_msg})
            return error_msg
    
    def _run(
        self,
        query: str,
        local_ids: Optional[List[str]] = None,
        section_range: Optional[List[float]] = None,
        min_score: float = 0.0,
        top_k: int = 10
    ) -> str:
        """Internal method to run the tool with parsed parameters."""
        try:
            self._log_debug("Getting query embedding", {"query": query})
            # Get query embedding from OpenAI
            response = self._openai_client.embeddings.create(
                model="text-embedding-3-large",
                input=[query]
            )
            query_embedding = response.data[0].embedding
            
            # First, get total chunks if we need section filtering
            total_chunks = None
            if section_range and len(section_range) == 2:
                # Query to get a sample document to determine total chunks
                sample_results = self._index.query(
                    namespace=self._namespace,
                    vector=query_embedding,
                    top_k=1,
                    include_metadata=True
                )
                if sample_results.get('matches'):
                    total_chunks = sample_results['matches'][0]['metadata'].get('total_chunks')
            
            # Build filter dictionary based on parameters
            filter_conditions = []
            
            # Add min_score filter if specified
            if min_score > 0:
                filter_conditions.append({"score": {"$gte": min_score}})
            
            # Handle local_ids filtering
            if local_ids and len(local_ids) > 0:
                # If there's only one ID, use $eq operator
                if len(local_ids) == 1:
                    filter_conditions.append({"local_id": {"$eq": local_ids[0]}})
                # If there are multiple IDs, use $in operator
                else:
                    filter_conditions.append({"local_id": {"$in": local_ids}})
            
            # Handle section_range filtering
            if section_range and len(section_range) == 2 and total_chunks:
                start_chunk, end_chunk = self._get_chunk_range(section_range, total_chunks)
                
                # Use $gte for start_chunk and $lt for end_chunk
                filter_conditions.append({"chunk_id": {"$gte": start_chunk}})
                filter_conditions.append({"chunk_id": {"$lt": end_chunk}})
            
            # Combine all conditions with $and operator if there are multiple conditions
            filter_dict = {}
            if filter_conditions:
                if len(filter_conditions) == 1:
                    filter_dict = filter_conditions[0]
                else:
                    filter_dict = {"$and": filter_conditions}
            
            self._log_debug("Querying Pinecone", {
                "namespace": self._namespace,
                "top_k": top_k,
                "filter": filter_dict
            })
            
            # Query the Pinecone index
            results = self._index.query(
                namespace=self._namespace,
                vector=query_embedding,
                top_k=top_k,
                filter=filter_dict if filter_dict else None,
                include_values=True,
                include_metadata=True
            )
            
            self._log_debug("Query completed", {"num_results": len(results.get('matches', []))})
            
            # Format and return the results
            return self._format_results(results, query)
            
        except Exception as e:
            error_msg = f"Error querying Pinecone: {str(e)}"
            self._log_debug("Query failed", {"error": error_msg})
            return error_msg
    
    def _format_results(self, results: Dict[str, Any], query: str, max_snippet_length: int = 300) -> str:
        """Format Pinecone query results for display using our schema fields.
        
        Args:
            results (Dict[str, Any]): The query results from Pinecone
            query (str): The original query string
            max_snippet_length (int): Maximum length for text snippets
            
        Returns:
            str: Formatted results string
        """
        if not results or not results.get('matches'):
            return f"No results found for query: '{query}'. Try broadening your search or using different keywords."
        
        # Start with a summary header
        summary = [
            f"## SEARCH RESULTS FOR: '{query}'",
            f"Found {len(results.get('matches', []))} relevant results.",
            "Below are the most relevant excerpts from research papers that match your query.",
            "Use these findings to support your research paper writing.",
            "\n"
        ]
        
        # Track unique papers for citation summary
        unique_papers = {}
        
        # Format individual results
        formatted_results = []
        for i, match in enumerate(results['matches']):
            similarity_score = match['score']  # Pinecone's similarity score
            metadata = match['metadata']
            
            # Extract all metadata fields
            local_id = metadata.get('local_id', 'Unknown')
            chunk_id = metadata.get('chunk_id', '?')
            total_chunks = metadata.get('total_chunks', '?')
            citation = metadata.get('citation', 'No citation available')
            relevance_score = metadata.get('score', 0.0)  # Custom relevance score
            text = metadata.get('text', '')
            
            # Track unique papers
            if local_id not in unique_papers and citation != 'No citation available':
                unique_papers[local_id] = citation
            
            # Format the result entry
            result = [
                f"### Result {i+1}:",
                f"**Paper ID:** {local_id} (Chunk {chunk_id} of {total_chunks})",
                f"**Relevance Score:** {relevance_score:.3f} | **Similarity Score:** {similarity_score:.3f}",
                f"**Citation:** {citation}",
                "\n**Content:**",
                "```"
            ]
            
            # Format the text content with truncation if needed
            if text:
                if len(text) > max_snippet_length:
                    text = text[:max_snippet_length] + "..."
                result.append(text)
            else:
                result.append("No text content available")
            
            result.append("```")
            
            # Add research notes and suggestions
            result.extend([
                "\n**Research Notes:**",
                f"- This excerpt comes from the {'introduction' if float(chunk_id)/float(total_chunks) < 0.15 else 'methodology' if float(chunk_id)/float(total_chunks) < 0.45 else 'results' if float(chunk_id)/float(total_chunks) < 0.75 else 'discussion' if float(chunk_id)/float(total_chunks) < 0.9 else 'conclusion'} section of the paper.",
                f"- To explore more from this paper, use: `local_ids: [\"{local_id}\"]`",
                f"- To find similar content in other papers, search for key terms from this excerpt."
            ])
            
            formatted_results.append("\n".join(result))
        
        # Add citation summary at the end
        if unique_papers:
            citation_summary = [
                "\n## CITATION SUMMARY",
                "The following papers were referenced in these results and may be valuable for your research:",
                ""
            ]
            
            for i, (paper_id, citation) in enumerate(unique_papers.items()):
                citation_summary.append(f"{i+1}. **{paper_id}**: {citation}")
            
            citation_summary.extend([
                "",
                "To cite these papers in your research, use the citation format provided above.",
                "To explore a specific paper in depth, use its Paper ID in your next search."
            ])
        else:
            citation_summary = []
        
        # Combine all parts
        all_parts = summary + formatted_results + citation_summary
        
        # Add search refinement suggestions
        refinement_suggestions = [
            "\n## SEARCH REFINEMENT SUGGESTIONS",
            "Based on these results, you might want to try:",
            f"- More specific query: Add technical terms from these results to your query",
            f"- Section targeting: Use section_range to focus on specific parts of papers",
            f"- Paper exploration: Use local_ids to explore promising papers in depth",
            f"- Comparative analysis: Use local_ids with multiple papers to compare approaches",
            "\nUse these suggestions to refine your search and gather more targeted information for your research paper."
        ]
        
        all_parts.extend(refinement_suggestions)
        
        return "\n".join(all_parts) 